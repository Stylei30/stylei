// 
// Decompiled by Procyon v0.5.36
// 

package net.runelite.client.plugins.DeadZonePestControl;

import com.google.common.collect.ImmutableSet;
import java.util.Set;

public final class DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178
{
    private static final Set<Integer> DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178;
    public static final Set<Integer> AB1CaddDEdaHI12361JKLM8NO3ka5gw;
    private static final Set<Integer> JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2;
    private static final Set<Integer> jkld2369IJgha561gkkbcFdaw1fa5def;
    private static final Set<Integer> PQRS23TgasdUVWX114666ce13Abefgh93f9awdf;
    private static final Set<Integer> asgn2kd1p2no455mnop2dqrstuvwxyz111146;
    private static final Set<Integer> jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq;
    private static final Set<Integer> cdefghi367869abcdefhJKL1234AB1Cad;
    private static final Set<Integer> vwxyzQdw3RSTUVwxyz11114XYZ1234;
    private static final Set<Integer> s6641asgn2kd1dasgha1333;
    private static final Set<Integer> nkdaflooqwEFGHIOPQRSTUV4666ce13Ab3;
    private static final Set<Integer> stuvwxdwyz1111EFda123ghaswGHIOP;
    private static final Set<Integer> FGw3gHIJdaw1faKLM8NO3ka5gwPQRS23;
    private static final Set<Integer> IOPQRSTUV4abcdefgJKLM8NO3ka5gM8;
    private static final Integer VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3;
    
    private static boolean AB1CaddDEdaHI12361JKLM8NO3ka5gw(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.contains(npcId);
    }
    
    private static boolean DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.AB1CaddDEdaHI12361JKLM8NO3ka5gw.contains(npcId);
    }
    
    private static boolean JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.contains(npcId);
    }
    
    private static boolean jkld2369IJgha561gkkbcFdaw1fa5def(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.jkld2369IJgha561gkkbcFdaw1fa5def.contains(npcId);
    }
    
    private static boolean PQRS23TgasdUVWX114666ce13Abefgh93f9awdf(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.contains(npcId);
    }
    
    private static boolean asgn2kd1p2no455mnop2dqrstuvwxyz111146(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.asgn2kd1p2no455mnop2dqrstuvwxyz111146.contains(npcId);
    }
    
    private static boolean jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq.contains(npcId);
    }
    
    private static boolean cdefghi367869abcdefhJKL1234AB1Cad(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.IOPQRSTUV4abcdefgJKLM8NO3ka5gM8.contains(npcId);
    }
    
    private static boolean vwxyzQdw3RSTUVwxyz11114XYZ1234(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 == npcId;
    }
    
    private static boolean s6641asgn2kd1dasgha1333(final int npcId) {
        return nkdaflooqwEFGHIOPQRSTUV4666ce13Ab3(npcId) || stuvwxdwyz1111EFda123ghaswGHIOP(npcId);
    }
    
    private static boolean nkdaflooqwEFGHIOPQRSTUV4666ce13Ab3(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.cdefghi367869abcdefhJKL1234AB1Cad.contains(npcId);
    }
    
    private static boolean stuvwxdwyz1111EFda123ghaswGHIOP(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.vwxyzQdw3RSTUVwxyz11114XYZ1234.contains(npcId);
    }
    
    private static boolean FGw3gHIJdaw1faKLM8NO3ka5gwPQRS23(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.s6641asgn2kd1dasgha1333.contains(npcId);
    }
    
    private static boolean IOPQRSTUV4abcdefgJKLM8NO3ka5gM8(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.nkdaflooqwEFGHIOPQRSTUV4666ce13Ab3.contains(npcId);
    }
    
    private static boolean VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.stuvwxdwyz1111EFda123ghaswGHIOP.contains(npcId);
    }
    
    private static boolean AB35raDWsFGHda212365IJKL12tfa1MNO(final int npcId) {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.FGw3gHIJdaw1faKLM8NO3ka5gwPQRS23.contains(npcId);
    }
    
    private static Set<Integer> vwxyzQdw3RSTUVwxyz11114XYZ1234() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178;
    }
    
    static Set<Integer> AB1CaddDEdaHI12361JKLM8NO3ka5gw() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.AB1CaddDEdaHI12361JKLM8NO3ka5gw;
    }
    
    static Set<Integer> DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2;
    }
    
    static Set<Integer> JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.jkld2369IJgha561gkkbcFdaw1fa5def;
    }
    
    static Set<Integer> jkld2369IJgha561gkkbcFdaw1fa5def() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf;
    }
    
    static Set<Integer> PQRS23TgasdUVWX114666ce13Abefgh93f9awdf() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.asgn2kd1p2no455mnop2dqrstuvwxyz111146;
    }
    
    static Set<Integer> asgn2kd1p2no455mnop2dqrstuvwxyz111146() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq;
    }
    
    static Set<Integer> jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.cdefghi367869abcdefhJKL1234AB1Cad;
    }
    
    static Set<Integer> cdefghi367869abcdefhJKL1234AB1Cad() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.vwxyzQdw3RSTUVwxyz11114XYZ1234;
    }
    
    private static Set<Integer> s6641asgn2kd1dasgha1333() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.s6641asgn2kd1dasgha1333;
    }
    
    private static Set<Integer> nkdaflooqwEFGHIOPQRSTUV4666ce13Ab3() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.nkdaflooqwEFGHIOPQRSTUV4666ce13Ab3;
    }
    
    private static Set<Integer> stuvwxdwyz1111EFda123ghaswGHIOP() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.stuvwxdwyz1111EFda123ghaswGHIOP;
    }
    
    private static Set<Integer> FGw3gHIJdaw1faKLM8NO3ka5gwPQRS23() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.FGw3gHIJdaw1faKLM8NO3ka5gwPQRS23;
    }
    
    private static Set<Integer> IOPQRSTUV4abcdefgJKLM8NO3ka5gM8() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.IOPQRSTUV4abcdefgJKLM8NO3ka5gM8;
    }
    
    private static Integer VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3() {
        return net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3;
    }
    
    static {
        DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178 = (Set)ImmutableSet.of((Object)1689, (Object)1690, (Object)1691, (Object)1692, (Object)1693);
        AB1CaddDEdaHI12361JKLM8NO3ka5gw = (Set)ImmutableSet.of((Object)1694, (Object)1695, (Object)1696, (Object)1697, (Object)1698, (Object)1699, (Object[])new Integer[] { 1700, 1701, 1702, 1703 });
        JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2 = (Set)ImmutableSet.of((Object)1709, (Object)1710, (Object)1711, (Object)1712, (Object)1713);
        jkld2369IJgha561gkkbcFdaw1fa5def = (Set)ImmutableSet.of((Object)1714, (Object)1715, (Object)1716, (Object)1717, (Object)1718, (Object)1719, (Object[])new Integer[] { 1720, 1721, 1722, 1723 });
        PQRS23TgasdUVWX114666ce13Abefgh93f9awdf = (Set)ImmutableSet.of((Object)1724, (Object)1725, (Object)1726, (Object)1727, (Object)1728, (Object)1729, (Object[])new Integer[] { 1730, 1731, 1732, 1733 });
        asgn2kd1p2no455mnop2dqrstuvwxyz111146 = (Set)ImmutableSet.of((Object)1734, (Object)1735, (Object)1736, (Object)1737, (Object)1738);
        jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq = (Set)ImmutableSet.of((Object)1704, (Object)1705, (Object)1706, (Object)1707, (Object)1708);
        cdefghi367869abcdefhJKL1234AB1Cad = (Set)ImmutableSet.of((Object)1747, (Object)1748, (Object)1749, (Object)1750, (Object)1739, (Object)1740, (Object[])new Integer[] { 1741, 1742 });
        vwxyzQdw3RSTUVwxyz11114XYZ1234 = (Set)ImmutableSet.of((Object)1751, (Object)1752, (Object)1753, (Object)1754, (Object)1743, (Object)1744, (Object[])new Integer[] { 1745, 1746 });
        s6641asgn2kd1dasgha1333 = (Set)ImmutableSet.of((Object)1747, (Object)1751, (Object)1739, (Object)1743);
        nkdaflooqwEFGHIOPQRSTUV4666ce13Ab3 = (Set)ImmutableSet.of((Object)1748, (Object)1752, (Object)1740, (Object)1744);
        stuvwxdwyz1111EFda123ghaswGHIOP = (Set)ImmutableSet.of((Object)1749, (Object)1753, (Object)1741, (Object)1745);
        FGw3gHIJdaw1faKLM8NO3ka5gwPQRS23 = (Set)ImmutableSet.of((Object)1750, (Object)1754, (Object)1742, (Object)1746);
        IOPQRSTUV4abcdefgJKLM8NO3ka5gM8 = (Set)ImmutableSet.of((Object)2950, (Object)2951, (Object)2952, (Object)2953);
        VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = 2949;
    }
}
