// 
// Decompiled by Procyon v0.5.36
// 

package net.runelite.client.plugins.DeadZonePestControl;

import net.runelite.client.util.ColorUtil;
import net.runelite.client.ui.overlay.components.table.TableAlignment;
import net.runelite.client.ui.overlay.components.table.TableComponent;
import java.awt.Color;
import net.runelite.client.ui.overlay.components.TitleComponent;
import java.awt.Dimension;
import java.awt.Graphics2D;
import javax.inject.Inject;
import net.runelite.client.ui.overlay.OverlayLayer;
import net.runelite.client.ui.overlay.OverlayPosition;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.ui.overlay.components.PanelComponent;
import net.runelite.client.ui.overlay.Overlay;

public final class JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2 extends Overlay
{
    private final DZPestControlPlugin DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178;
    private final AB1CaddDEdaHI12361JKLM8NO3ka5gw JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2;
    public PanelComponent AB1CaddDEdaHI12361JKLM8NO3ka5gw;
    
    @Inject
    private JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2(final DZPestControlPlugin plugin, final AB1CaddDEdaHI12361JKLM8NO3ka5gw config) {
        super((Plugin)plugin);
        this.AB1CaddDEdaHI12361JKLM8NO3ka5gw = new PanelComponent();
        this.setPosition(OverlayPosition.BOTTOM_LEFT);
        this.setLayer(OverlayLayer.ABOVE_SCENE);
        this.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178 = plugin;
        this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2 = config;
    }
    
    public final Dimension render(final Graphics2D graphics) {
        if (this.AB1CaddDEdaHI12361JKLM8NO3ka5gw != null) {
            this.AB1CaddDEdaHI12361JKLM8NO3ka5gw.getChildren().clear();
            if (this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178()) {
                final TitleComponent title = TitleComponent.builder().text("Pest Control").color(Color.GREEN).build();
                this.AB1CaddDEdaHI12361JKLM8NO3ka5gw.getChildren().add(title);
                final TableComponent tableComponent;
                (tableComponent = new TableComponent()).setColumnAlignments(new TableAlignment[] { TableAlignment.LEFT, TableAlignment.RIGHT });
                tableComponent.setGutter(new Dimension(5, 3));
                tableComponent.addRow(new String[] { "Active:", ColorUtil.prependColorTag(invokedynamic(makeConcatWithConstants:(Z)Ljava/lang/String;, this.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178()), this.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178() ? Color.GREEN : Color.RED) });
                tableComponent.addRow(new String[] { "Boat:", String.valueOf(this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2()) });
                tableComponent.addRow(new String[] { "Stage:", this.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2() });
                tableComponent.addRow(new String[] { "Time left:", invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, this.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.AB1CaddDEdaHI12361JKLM8NO3ka5gw()) });
                this.AB1CaddDEdaHI12361JKLM8NO3ka5gw.getChildren().add(tableComponent);
                this.AB1CaddDEdaHI12361JKLM8NO3ka5gw.setPreferredSize(new Dimension(140, this.AB1CaddDEdaHI12361JKLM8NO3ka5gw.getBounds().height));
            }
            return this.AB1CaddDEdaHI12361JKLM8NO3ka5gw.render(graphics);
        }
        return null;
    }
}
