// 
// Decompiled by Procyon v0.5.36
// 

package net.runelite.client.plugins.DeadZonePestControl;

import org.slf4j.LoggerFactory;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;
import net.runelite.api.NPC;
import java.util.Set;
import net.runelite.api.WallObject;
import java.util.Collection;
import java.util.HashSet;
import net.runelite.api.MenuEntry;
import java.util.Objects;
import net.runelite.api.Player;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Arrays;
import java.time.temporal.Temporal;
import java.time.Duration;
import net.runelite.api.GameState;
import net.runelite.api.events.GameStateChanged;
import net.runelite.api.events.ChatMessage;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.api.ChatMessageType;
import net.runelite.api.events.GameTick;
import net.runelite.client.util.ColorUtil;
import java.awt.Color;
import net.runelite.client.ui.overlay.Overlay;
import com.google.inject.Provides;
import net.runelite.client.config.ConfigManager;
import net.runelite.api.coords.LocalPoint;
import java.time.Instant;
import java.util.concurrent.ScheduledExecutorService;
import net.runelite.client.input.KeyManager;
import net.runelite.client.plugins.DeadZoneAPI.IOPQRSTUV4abcdefgJKLM8NO3ka5gM8;
import net.runelite.client.ui.overlay.OverlayManager;
import net.runelite.client.plugins.DeadZoneAPI.stuvwxdwyz1111EFda123ghaswGHIOP;
import javax.inject.Inject;
import net.runelite.api.Client;
import org.slf4j.Logger;
import net.runelite.client.plugins.DeadZoneAPI.DeadZoneAPI;
import net.runelite.client.plugins.PluginDependency;
import net.runelite.client.plugins.PluginType;
import net.runelite.client.plugins.PluginDescriptor;
import org.pf4j.Extension;
import net.runelite.client.input.KeyListener;
import net.runelite.client.plugins.Plugin;

@Extension
@PluginDescriptor(name = "DZ Pest Control", description = "Configure DeadZone Pest Control Helper", tags = { "deadzone", "johnny", "bot", "helper" }, type = PluginType.MINIGAME, enabledByDefault = false)
@PluginDependency(DeadZoneAPI.class)
public class DZPestControlPlugin extends Plugin implements KeyListener
{
    private static final Logger DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178;
    @Inject
    private Client JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2;
    @Inject
    private DeadZoneAPI jkld2369IJgha561gkkbcFdaw1fa5def;
    @Inject
    private stuvwxdwyz1111EFda123ghaswGHIOP PQRS23TgasdUVWX114666ce13Abefgh93f9awdf;
    @Inject
    private JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2 asgn2kd1p2no455mnop2dqrstuvwxyz111146;
    @Inject
    private OverlayManager jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq;
    @Inject
    private IOPQRSTUV4abcdefgJKLM8NO3ka5gM8 cdefghi367869abcdefhJKL1234AB1Cad;
    @Inject
    private KeyManager vwxyzQdw3RSTUVwxyz11114XYZ1234;
    @Inject
    private AB1CaddDEdaHI12361JKLM8NO3ka5gw s6641asgn2kd1dasgha1333;
    private final int nkdaflooqwEFGHIOPQRSTUV4666ce13Ab3 = 14315;
    private final int stuvwxdwyz1111EFda123ghaswGHIOP = 25631;
    private final int FGw3gHIJdaw1faKLM8NO3ka5gwPQRS23 = 25632;
    public String AB1CaddDEdaHI12361JKLM8NO3ka5gw;
    private ScheduledExecutorService IOPQRSTUV4abcdefgJKLM8NO3ka5gM8;
    private boolean VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3;
    private boolean AB35raDWsFGHda212365IJKL12tfa1MNO;
    private Instant dIJgha561gkkbcFdaw1fa5def;
    private Instant PQRS23TUVWX112e4666ce13Abefghi893f9awdf;
    private Instant asgn2kd1p2nopda2kd1dafl2Fqrstuxyz111146;
    private boolean UVasWXYd2aZ123456fhg581dafl2FFfawff;
    private final int fas3a5580asgn2ksgnkdag580asgn2kd1dafl = 5000;
    private int fl2FFdaw16ffa5Vg580asg1234ABn2kd1dafl2F;
    private LocalPoint CDEs6FGHdDE6FGw3DE6FGw3gHIJ;
    private LocalPoint ahCDWsEFGHda12da265IJKL12tfa1MNO;
    private static final int[] DEFGHI1sdfggwPQRSTUVop2qrstuvwxyz178;
    private static final int[] JKLM8NO3k8NO213ka5gM8NO3ka5gwPQRS2;
    private boolean jkl2awf3455sgmnop2dadqrstuvwxyz111146;
    private boolean jkl2345O3kasgfha15gM8NO3ka5;
    private String STUVWXYZ1234AB1CaddDxyz11114666ce13A;
    private int gwPQhRSTUVop52fdaqrstuvwxyz11114X45678;
    
    public DZPestControlPlugin() {
        this.AB1CaddDEdaHI12361JKLM8NO3ka5gw = "";
        this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
        this.AB35raDWsFGHda212365IJKL12tfa1MNO = false;
        this.UVasWXYd2aZ123456fhg581dafl2FFfawff = false;
        this.fl2FFdaw16ffa5Vg580asg1234ABn2kd1dafl2F = 5000;
        this.CDEs6FGHdDE6FGw3DE6FGw3gHIJ = null;
        this.ahCDWsEFGHda12da265IJKL12tfa1MNO = null;
        this.jkl2awf3455sgmnop2dadqrstuvwxyz111146 = false;
        this.jkl2345O3kasgfha15gM8NO3ka5 = false;
        this.gwPQhRSTUVop52fdaqrstuvwxyz11114X45678 = -1;
    }
    
    @Provides
    private static AB1CaddDEdaHI12361JKLM8NO3ka5gw AB1CaddDEdaHI12361JKLM8NO3ka5gw(final ConfigManager configManager) {
        return (AB1CaddDEdaHI12361JKLM8NO3ka5gw)configManager.getConfig((Class)AB1CaddDEdaHI12361JKLM8NO3ka5gw.class);
    }
    
    protected void startUp() {
        this.vwxyzQdw3RSTUVwxyz11114XYZ1234.registerKeyListener((KeyListener)this);
        this.jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq.add((Overlay)this.asgn2kd1p2no455mnop2dqrstuvwxyz111146);
        this.IOPQRSTUV4abcdefgJKLM8NO3ka5gM8 = this.jkld2369IJgha561gkkbcFdaw1fa5def.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178;
        this.AB1CaddDEdaHI12361JKLM8NO3ka5gw = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, ColorUtil.wrapWithColorTag("| ", Color.yellow), ColorUtil.wrapWithColorTag("Pest Control", Color.green), ColorUtil.wrapWithColorTag(" | ", Color.yellow));
    }
    
    protected void shutDown() {
        this.vwxyzQdw3RSTUVwxyz11114XYZ1234.unregisterKeyListener((KeyListener)this);
        this.jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq.remove((Overlay)this.asgn2kd1p2no455mnop2dqrstuvwxyz111146);
    }
    
    @Subscribe
    private void AB1CaddDEdaHI12361JKLM8NO3ka5gw(final GameTick event) {
        if (this.AB35raDWsFGHda212365IJKL12tfa1MNO && this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer() != null) {
            this.IOPQRSTUV4abcdefgJKLM8NO3ka5gM8();
            if (this.asgn2kd1p2no455mnop2dqrstuvwxyz111146() && !this.jkld2369IJgha561gkkbcFdaw1fa5def()) {
                DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Timeout limit reached, shutting down!");
                this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.addChatMessage(ChatMessageType.GAMEMESSAGE, "", invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.AB1CaddDEdaHI12361JKLM8NO3ka5gw), (String)null);
                this.s6641asgn2kd1dasgha1333();
                return;
            }
            if (this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf() && this.jkl2awf3455sgmnop2dadqrstuvwxyz111146) {
                this.jkl2awf3455sgmnop2dadqrstuvwxyz111146 = false;
            }
            if (this.asgn2kd1p2no455mnop2dqrstuvwxyz111146() && this.jkl2345O3kasgfha15gM8NO3ka5) {
                System.out.println("Game Finished..");
                this.jkl2345O3kasgfha15gM8NO3ka5 = false;
                this.ahCDWsEFGHda12da265IJKL12tfa1MNO = this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer().getLocalLocation();
                final int jkld2369IJgha561gkkbcFdaw1fa5def;
                if (this.gwPQhRSTUVop52fdaqrstuvwxyz11114X45678 == -1 && (jkld2369IJgha561gkkbcFdaw1fa5def = net.runelite.client.plugins.DeadZoneAPI.stuvwxdwyz1111EFda123ghaswGHIOP.jkld2369IJgha561gkkbcFdaw1fa5def(1, 100)) <= 8 && this.s6641asgn2kd1dasgha1333.asgn2kd1p2no455mnop2dqrstuvwxyz111146()) {
                    DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Skilling Break Activated");
                    this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.addChatMessage(ChatMessageType.GAMEMESSAGE, "", invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.AB1CaddDEdaHI12361JKLM8NO3ka5gw), (String)null);
                    this.gwPQhRSTUVop52fdaqrstuvwxyz11114X45678 = 0;
                }
            }
            else {
                if (!this.jkl2awf3455sgmnop2dadqrstuvwxyz111146 && !this.jkl2345O3kasgfha15gM8NO3ka5 && this.gwPQhRSTUVop52fdaqrstuvwxyz11114X45678 == -1 && this.asgn2kd1p2no455mnop2dqrstuvwxyz111146() && !this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3) {
                    if (!this.AB1CaddDEdaHI12361JKLM8NO3ka5gw(this.ahCDWsEFGHda12da265IJKL12tfa1MNO)) {
                        DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Found boat!");
                        this.jkl2awf3455sgmnop2dadqrstuvwxyz111146 = true;
                        return;
                    }
                    DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Finding boat...");
                    this.PQRS23TUVWX112e4666ce13Abefghi893f9awdf = null;
                    this.FGw3gHIJdaw1faKLM8NO3ka5gwPQRS23();
                }
                else if (this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf() && !this.jkl2345O3kasgfha15gM8NO3ka5 && !this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3) {
                    System.out.println("Game Started...");
                    this.jkl2awf3455sgmnop2dadqrstuvwxyz111146 = false;
                    this.jkl2345O3kasgfha15gM8NO3ka5 = true;
                    this.stuvwxdwyz1111EFda123ghaswGHIOP();
                }
                else if (this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf() && this.jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq() && !this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 && !this.cdefghi367869abcdefhJKL1234AB1Cad() && this.UVasWXYd2aZ123456fhg581dafl2FFfawff) {
                    System.out.println("Finding target...");
                    if (this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3()) {
                        System.out.println("Detected not finding target, opening nearest gate!");
                        this.PQRS23TUVWX112e4666ce13Abefghi893f9awdf = Instant.now();
                        this.nkdaflooqwEFGHIOPQRSTUV4666ce13Ab3();
                        return;
                    }
                    this.AB1CaddDEdaHI12361JKLM8NO3ka5gw(true);
                    this.fl2FFdaw16ffa5Vg580asg1234ABn2kd1dafl2F += 1000;
                }
                else if (this.dIJgha561gkkbcFdaw1fa5def == null && this.cdefghi367869abcdefhJKL1234AB1Cad()) {
                    System.out.println("Finding new target...");
                    this.AB1CaddDEdaHI12361JKLM8NO3ka5gw(true);
                }
                this.CDEs6FGHdDE6FGw3DE6FGw3gHIJ = this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer().getLocalLocation();
            }
        }
    }
    
    @Subscribe
    private void AB1CaddDEdaHI12361JKLM8NO3ka5gw(final ChatMessage message) {
        if (message.getMessage().equals("I can't reach that!") && !this.jkl2awf3455sgmnop2dadqrstuvwxyz111146) {
            System.out.println("Found boat!");
            this.jkl2awf3455sgmnop2dadqrstuvwxyz111146 = true;
        }
    }
    
    @Subscribe
    private void AB1CaddDEdaHI12361JKLM8NO3ka5gw(final GameStateChanged event) {
        if (event.getGameState() == GameState.LOGIN_SCREEN && this.AB35raDWsFGHda212365IJKL12tfa1MNO) {
            this.s6641asgn2kd1dasgha1333();
        }
    }
    
    private boolean jkld2369IJgha561gkkbcFdaw1fa5def() {
        if (this.asgn2kd1p2nopda2kd1dafl2Fqrstuxyz111146 != null) {
            final Duration timeout = Duration.ofMinutes(this.s6641asgn2kd1dasgha1333.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf());
            return Duration.between(this.asgn2kd1p2nopda2kd1dafl2Fqrstuxyz111146, Instant.now()).compareTo(timeout) < 0;
        }
        return false;
    }
    
    public final long AB1CaddDEdaHI12361JKLM8NO3ka5gw() {
        if (this.asgn2kd1p2nopda2kd1dafl2Fqrstuxyz111146 != null) {
            final Duration between = Duration.between(this.asgn2kd1p2nopda2kd1dafl2Fqrstuxyz111146, Instant.now());
            return this.s6641asgn2kd1dasgha1333.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf() - between.toMinutes();
        }
        return this.s6641asgn2kd1dasgha1333.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf();
    }
    
    public final boolean DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178() {
        return this.AB35raDWsFGHda212365IJKL12tfa1MNO;
    }
    
    public final String JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2() {
        return this.STUVWXYZ1234AB1CaddDxyz11114666ce13A;
    }
    
    private boolean PQRS23TgasdUVWX114666ce13Abefgh93f9awdf() {
        return this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer() != null && Arrays.equals(this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getMapRegions(), DZPestControlPlugin.DEFGHI1sdfggwPQRSTUVop2qrstuvwxyz178);
    }
    
    private boolean asgn2kd1p2no455mnop2dqrstuvwxyz111146() {
        if (this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer() == null) {
            return false;
        }
        final List<Integer> mapRegions = Arrays.stream(this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getMapRegions()).boxed().collect((Collector<? super Integer, ?, List<Integer>>)Collectors.toList());
        int[] jklm8NO3k8NO213ka5gM8NO3ka5gwPQRS2;
        for (int length = (jklm8NO3k8NO213ka5gM8NO3ka5gwPQRS2 = DZPestControlPlugin.JKLM8NO3k8NO213ka5gM8NO3ka5gwPQRS2).length, j = 0; j < length; ++j) {
            final int i = jklm8NO3k8NO213ka5gM8NO3ka5gwPQRS2[j];
            if (!mapRegions.contains(i)) {
                return false;
            }
        }
        return true;
    }
    
    private boolean AB1CaddDEdaHI12361JKLM8NO3ka5gw(final LocalPoint location) {
        return location.getX() == Objects.requireNonNull(this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer()).getLocalLocation().getX() && location.getY() == this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer().getLocalLocation().getY();
    }
    
    private boolean jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq() {
        return this.CDEs6FGHdDE6FGw3DE6FGw3gHIJ.getX() == Objects.requireNonNull(this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer()).getLocalLocation().getX() && this.CDEs6FGHdDE6FGw3DE6FGw3gHIJ.getY() == this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer().getLocalLocation().getY();
    }
    
    private boolean cdefghi367869abcdefhJKL1234AB1Cad() {
        if (Objects.requireNonNull(this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer()).getInteracting() != null) {
            this.PQRS23TUVWX112e4666ce13Abefghi893f9awdf = Instant.now();
            return true;
        }
        return false;
    }
    
    private void vwxyzQdw3RSTUVwxyz11114XYZ1234() {
        if (this.jkld2369IJgha561gkkbcFdaw1fa5def.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2() && this.IOPQRSTUV4abcdefgJKLM8NO3ka5gM8 != null && this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer() != null) {
            this.asgn2kd1p2nopda2kd1dafl2Fqrstuxyz111146 = Instant.now();
            this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Startup";
            this.jkl2awf3455sgmnop2dadqrstuvwxyz111146 = false;
            this.jkl2345O3kasgfha15gM8NO3ka5 = false;
            this.ahCDWsEFGHda12da265IJKL12tfa1MNO = this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer().getLocalLocation();
            this.CDEs6FGHdDE6FGw3DE6FGw3gHIJ = this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer().getLocalLocation();
            this.gwPQhRSTUVop52fdaqrstuvwxyz11114X45678 = -1;
            this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
            this.AB35raDWsFGHda212365IJKL12tfa1MNO = true;
        }
    }
    
    private void s6641asgn2kd1dasgha1333() {
        this.AB35raDWsFGHda212365IJKL12tfa1MNO = false;
        this.asgn2kd1p2nopda2kd1dafl2Fqrstuxyz111146 = null;
        this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Stopped";
        this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
    }
    
    private void nkdaflooqwEFGHIOPQRSTUV4666ce13Ab3() {
        this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = true;
        this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Gate";
        final WallObject gate;
        final Object o;
        int param0;
        int param2;
        MenuEntry entry;
        HashSet<Object> setIDs;
        final Set<Object> set;
        int[] npcIds;
        NPC closestActivePortal;
        final Object o2;
        this.IOPQRSTUV4abcdefgJKLM8NO3ka5gM8.submit(() -> {
            gate = this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.asgn2kd1p2no455mnop2dqrstuvwxyz111146(new int[] { 14233, 14235 });
            if (o != null) {
                DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Found Nearest Closed Gate!");
                param0 = gate.getLocalLocation().getSceneX();
                param2 = gate.getLocalLocation().getSceneY();
                entry = new MenuEntry("", "", gate.getId(), 3, param0, param2, false);
                this.cdefghi367869abcdefhJKL1234AB1Cad.AB1CaddDEdaHI12361JKLM8NO3ka5gw(entry);
            }
            else {
                DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Couldn't find closed gate, finding closest portal to attack...");
                setIDs = new HashSet<Object>();
                set.addAll(net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq());
                setIDs.addAll(net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.cdefghi367869abcdefhJKL1234AB1Cad());
                npcIds = setIDs.stream().mapToInt(Integer::intValue).toArray();
                closestActivePortal = this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.jkld2369IJgha561gkkbcFdaw1fa5def(npcIds);
                if (o2 != null && this.AB1CaddDEdaHI12361JKLM8NO3ka5gw(closestActivePortal, false, 0)) {
                    DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Found Portal to attack!");
                }
            }
            this.UVasWXYd2aZ123456fhg581dafl2FFfawff = true;
            this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Passive";
            this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
        });
    }
    
    private void stuvwxdwyz1111EFda123ghaswGHIOP() {
        this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = true;
        this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Game Started";
        final WallObject gate;
        final Object o;
        int param0;
        int param2;
        MenuEntry entry;
        this.IOPQRSTUV4abcdefgJKLM8NO3ka5gM8.schedule(() -> {
            try {
                Thread.sleep(net.runelite.client.plugins.DeadZoneAPI.stuvwxdwyz1111EFda123ghaswGHIOP.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf(500, 1000));
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            gate = this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.asgn2kd1p2no455mnop2dqrstuvwxyz111146(new int[] { 14233, 14235 });
            if (o != null) {
                System.out.println("Found Nearest Closed Gate!");
                param0 = gate.getLocalLocation().getSceneX();
                param2 = gate.getLocalLocation().getSceneY();
                entry = new MenuEntry("", "", gate.getId(), 3, param0, param2, false);
                this.cdefghi367869abcdefhJKL1234AB1Cad.AB1CaddDEdaHI12361JKLM8NO3ka5gw(entry);
            }
            this.UVasWXYd2aZ123456fhg581dafl2FFfawff = true;
            this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Passive";
            this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
        }, this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.AB1CaddDEdaHI12361JKLM8NO3ka5gw(), TimeUnit.MILLISECONDS);
    }
    
    private void FGw3gHIJdaw1faKLM8NO3ka5gwPQRS23() {
        this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = true;
        this.IOPQRSTUV4abcdefgJKLM8NO3ka5gM8.schedule(() -> {
            this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Joining";
            switch (DZPestControlPlugin$1.AB1CaddDEdaHI12361JKLM8NO3ka5gw[this.s6641asgn2kd1dasgha1333.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2().ordinal()]) {
                case 1: {
                    if (this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.s6641asgn2kd1dasgha1333(new int[] { 14315 }) != net.runelite.client.plugins.DeadZoneAPI.stuvwxdwyz1111EFda123ghaswGHIOP.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.AB1CaddDEdaHI12361JKLM8NO3ka5gw) {
                        this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.AB1CaddDEdaHI12361JKLM8NO3ka5gw(3, new int[] { 14315 });
                        break;
                    }
                    else {
                        break;
                    }
                    break;
                }
                case 2: {
                    if (this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.s6641asgn2kd1dasgha1333(new int[] { 25631 }) != net.runelite.client.plugins.DeadZoneAPI.stuvwxdwyz1111EFda123ghaswGHIOP.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.AB1CaddDEdaHI12361JKLM8NO3ka5gw) {
                        this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.AB1CaddDEdaHI12361JKLM8NO3ka5gw(3, new int[] { 25631 });
                        break;
                    }
                    else {
                        break;
                    }
                    break;
                }
                case 3: {
                    if (this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.s6641asgn2kd1dasgha1333(new int[] { 25632 }) != net.runelite.client.plugins.DeadZoneAPI.stuvwxdwyz1111EFda123ghaswGHIOP.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.AB1CaddDEdaHI12361JKLM8NO3ka5gw) {
                        this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.AB1CaddDEdaHI12361JKLM8NO3ka5gw(3, new int[] { 25632 });
                        break;
                    }
                    else {
                        break;
                    }
                    break;
                }
            }
            try {
                Thread.sleep(net.runelite.client.plugins.DeadZoneAPI.stuvwxdwyz1111EFda123ghaswGHIOP.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf(850, 1250));
            }
            catch (Exception e) {
                DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info(String.valueOf(e));
            }
            this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Waiting";
            this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
        }, this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.AB1CaddDEdaHI12361JKLM8NO3ka5gw(), TimeUnit.MILLISECONDS);
    }
    
    private void AB1CaddDEdaHI12361JKLM8NO3ka5gw(final boolean distanceCheck) {
        this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = true;
        this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Target";
        final Object o;
        final NPC npc;
        NPC jkld2369IJgha561gkkbcFdaw1fa5def;
        int[] portalIDs;
        NPC closestActivePortal;
        NPC jkld2369IJgha561gkkbcFdaw1fa5def2;
        HashSet<Object> setIDs;
        final Set<Object> set;
        NPC jkld2369IJgha561gkkbcFdaw1fa5def3;
        this.IOPQRSTUV4abcdefgJKLM8NO3ka5gM8.submit(() -> {
            this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.jkld2369IJgha561gkkbcFdaw1fa5def(net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf().stream().mapToInt(Integer::intValue).toArray());
            if (o != null && this.AB1CaddDEdaHI12361JKLM8NO3ka5gw(npc, distanceCheck, 500)) {
                DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Found Brawler within small range to attack!");
                this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Passive";
                this.PQRS23TUVWX112e4666ce13Abefghi893f9awdf = Instant.now();
                this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
            }
            else if ((jkld2369IJgha561gkkbcFdaw1fa5def = this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.jkld2369IJgha561gkkbcFdaw1fa5def(net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178().stream().mapToInt(Integer::intValue).toArray())) != null && this.AB1CaddDEdaHI12361JKLM8NO3ka5gw(jkld2369IJgha561gkkbcFdaw1fa5def, distanceCheck, 0)) {
                DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Found Spinner to attack!");
                this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Passive";
                this.PQRS23TUVWX112e4666ce13Abefghi893f9awdf = Instant.now();
                this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
            }
            else {
                portalIDs = net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.jkl2dawd345O3kd5a5gM8NO3ka5gwP5mnop2dq().stream().mapToInt(Integer::intValue).toArray();
                if ((closestActivePortal = this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.jkld2369IJgha561gkkbcFdaw1fa5def(portalIDs)) != null && this.AB1CaddDEdaHI12361JKLM8NO3ka5gw(closestActivePortal, distanceCheck, this.fl2FFdaw16ffa5Vg580asg1234ABn2kd1dafl2F + 2000)) {
                    DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Found Portal to attack!");
                    this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Passive";
                    this.PQRS23TUVWX112e4666ce13Abefghi893f9awdf = Instant.now();
                    this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
                }
                else if ((jkld2369IJgha561gkkbcFdaw1fa5def2 = this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.jkld2369IJgha561gkkbcFdaw1fa5def(net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf().stream().mapToInt(Integer::intValue).toArray())) != null && this.AB1CaddDEdaHI12361JKLM8NO3ka5gw(jkld2369IJgha561gkkbcFdaw1fa5def2, distanceCheck, 0)) {
                    DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Found Brawler to attack!");
                    this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Passive";
                    this.PQRS23TUVWX112e4666ce13Abefghi893f9awdf = Instant.now();
                    this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
                }
                else {
                    setIDs = new HashSet<Object>();
                    set.addAll(net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2());
                    setIDs.addAll(net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.asgn2kd1p2no455mnop2dqrstuvwxyz111146());
                    setIDs.addAll(net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.jkld2369IJgha561gkkbcFdaw1fa5def());
                    setIDs.addAll(net.runelite.client.plugins.DeadZonePestControl.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.AB1CaddDEdaHI12361JKLM8NO3ka5gw());
                    if ((jkld2369IJgha561gkkbcFdaw1fa5def3 = this.PQRS23TgasdUVWX114666ce13Abefgh93f9awdf.jkld2369IJgha561gkkbcFdaw1fa5def(setIDs.stream().mapToInt(Integer::intValue).toArray())) != null && this.AB1CaddDEdaHI12361JKLM8NO3ka5gw(jkld2369IJgha561gkkbcFdaw1fa5def3, distanceCheck, 0)) {
                        DZPestControlPlugin.DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178.info("Found Torcher, Ravager, Defiler or Shifter to attack!");
                        this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Passive";
                        this.PQRS23TUVWX112e4666ce13Abefghi893f9awdf = Instant.now();
                        this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
                    }
                    else {
                        this.dIJgha561gkkbcFdaw1fa5def = Instant.now();
                        this.STUVWXYZ1234AB1CaddDxyz11114666ce13A = "Passive";
                        this.VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3 = false;
                    }
                }
            }
        });
    }
    
    private void IOPQRSTUV4abcdefgJKLM8NO3ka5gM8() {
        if (this.dIJgha561gkkbcFdaw1fa5def != null) {
            final Duration retryTime = Duration.ofMillis(net.runelite.client.plugins.DeadZoneAPI.stuvwxdwyz1111EFda123ghaswGHIOP.jkld2369IJgha561gkkbcFdaw1fa5def(3500, 5500));
            final Duration between;
            if ((between = Duration.between(this.dIJgha561gkkbcFdaw1fa5def, Instant.now())).toSeconds() >= Duration.ofSeconds(1L).toSeconds()) {
                this.UVasWXYd2aZ123456fhg581dafl2FFfawff = true;
            }
            if (between.compareTo(retryTime) >= 0) {
                this.dIJgha561gkkbcFdaw1fa5def = null;
            }
        }
        else {
            this.UVasWXYd2aZ123456fhg581dafl2FFfawff = true;
        }
        if (this.gwPQhRSTUVop52fdaqrstuvwxyz11114X45678 >= 0) {
            final int random = net.runelite.client.plugins.DeadZoneAPI.stuvwxdwyz1111EFda123ghaswGHIOP.jkld2369IJgha561gkkbcFdaw1fa5def(8, 22);
            if (this.gwPQhRSTUVop52fdaqrstuvwxyz11114X45678 + 1 >= random) {
                this.gwPQhRSTUVop52fdaqrstuvwxyz11114X45678 = -1;
                return;
            }
            ++this.gwPQhRSTUVop52fdaqrstuvwxyz11114X45678;
        }
    }
    
    private boolean VWXcdefghi3FGYZ13Ab3558933gHIJKLM8NO3() {
        return this.PQRS23TUVWX112e4666ce13Abefghi893f9awdf != null && Duration.between(this.PQRS23TUVWX112e4666ce13Abefghi893f9awdf, Instant.now()).toSeconds() >= Duration.ofSeconds(8L).toSeconds();
    }
    
    private boolean AB1CaddDEdaHI12361JKLM8NO3ka5gw(final NPC npc, final boolean distanceCheck, final int customDistance) {
        if (distanceCheck) {
            if (customDistance != 0) {
                if (npc.getLocalLocation().distanceTo(Objects.requireNonNull(this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer()).getLocalLocation()) > customDistance) {
                    return false;
                }
            }
            else if (npc.getLocalLocation().distanceTo(Objects.requireNonNull(this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getLocalPlayer()).getLocalLocation()) > this.fl2FFdaw16ffa5Vg580asg1234ABn2kd1dafl2F) {
                return false;
            }
        }
        final MenuEntry entry = new MenuEntry("", "", npc.getIndex(), 10, 0, 0, false);
        this.cdefghi367869abcdefhJKL1234AB1Cad.AB1CaddDEdaHI12361JKLM8NO3ka5gw(entry);
        this.dIJgha561gkkbcFdaw1fa5def = Instant.now();
        this.UVasWXYd2aZ123456fhg581dafl2FFfawff = false;
        this.fl2FFdaw16ffa5Vg580asg1234ABn2kd1dafl2F = 5000;
        return true;
    }
    
    public void keyTyped(final KeyEvent keyEvent) {
    }
    
    public void keyPressed(final KeyEvent keyEvent) {
        if (this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getGameState() == GameState.LOGGED_IN && this.s6641asgn2kd1dasgha1333.jkld2369IJgha561gkkbcFdaw1fa5def().matches(keyEvent) && this.JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2.getCanvas().hasFocus()) {
            if (!this.AB35raDWsFGHda212365IJKL12tfa1MNO) {
                this.vwxyzQdw3RSTUVwxyz11114XYZ1234();
                return;
            }
            this.s6641asgn2kd1dasgha1333();
        }
    }
    
    public void keyReleased(final KeyEvent keyEvent) {
    }
    
    static {
        DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178 = LoggerFactory.getLogger((Class)DZPestControlPlugin.class);
        DEFGHI1sdfggwPQRSTUVop2qrstuvwxyz178 = new int[] { 10536 };
        JKLM8NO3k8NO213ka5gM8NO3ka5gwPQRS2 = new int[] { 10537 };
    }
}
