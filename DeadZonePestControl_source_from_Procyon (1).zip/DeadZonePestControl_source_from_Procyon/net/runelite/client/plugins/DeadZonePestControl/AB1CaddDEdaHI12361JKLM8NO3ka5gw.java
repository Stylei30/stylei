// 
// Decompiled by Procyon v0.5.36
// 

package net.runelite.client.plugins.DeadZonePestControl;

import net.runelite.client.config.Range;
import net.runelite.client.config.Keybind;
import net.runelite.client.config.ConfigItem;
import net.runelite.client.config.ConfigTitleSection;
import net.runelite.client.config.Title;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.Config;

@ConfigGroup("DZPestControl")
public interface AB1CaddDEdaHI12361JKLM8NO3ka5gw extends Config
{
    @ConfigTitleSection(keyName = "pcontrolTitle", name = "Pest Control Config", position = 0, description = "")
    default Title AB1CaddDEdaHI12361JKLM8NO3ka5gw() {
        return new Title();
    }
    
    @ConfigItem(keyName = "displayInfo", name = "Display Info Panel", position = 0, description = "Enable to display info regarding the Pest Control Helper", titleSection = "pcontrolTitle")
    default boolean DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178() {
        return true;
    }
    
    @ConfigItem(keyName = "boat", name = "Boat", position = 1, description = "Determine which boat the script will use", titleSection = "pcontrolTitle")
    default AB1CaddDEdaHI12361JKLM8NO3ka5gw JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2() {
        return AB1CaddDEdaHI12361JKLM8NO3ka5gw.AB1CaddDEdaHI12361JKLM8NO3ka5gw;
    }
    
    @ConfigItem(keyName = "toggleKey", name = "Toggle Key", description = "Toggles the Pest Control Helper on / off", position = 2, titleSection = "pcontrolTitle")
    default Keybind jkld2369IJgha561gkkbcFdaw1fa5def() {
        return new Keybind(97, 0);
    }
    
    @ConfigItem(keyName = "timeout", name = "Skilling Timeout", description = "How long to run the Pest Control Plugin before timing out automatically", position = 3, titleSection = "pcontrolTitle")
    @Range(min = 5, max = 500)
    default int PQRS23TgasdUVWX114666ce13Abefgh93f9awdf() {
        return 10;
    }
    
    @ConfigItem(keyName = "skillBreaks", name = "Skilling Breaks", description = "Stops the bot from running randomly for a period of time before resuming again", position = 4, titleSection = "pcontrolTitle")
    default boolean asgn2kd1p2no455mnop2dqrstuvwxyz111146() {
        return true;
    }
    
    public enum AB1CaddDEdaHI12361JKLM8NO3ka5gw
    {
        AB1CaddDEdaHI12361JKLM8NO3ka5gw, 
        DEFGvsdHI1sfggwPQRSTUdfVop2qrstuz178, 
        JKaFLM8NO3ka5g12M8NO3ka5gwPQRS2;
    }
}
